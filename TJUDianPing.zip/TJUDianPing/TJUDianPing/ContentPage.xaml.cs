﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TJUDianPing
{
    public partial class ContentPage : PhoneApplicationPage
    {
        public ContentPage()
        {
            InitializeComponent();
        }

        private void ApplicationBarAddButton_Click(object sender, System.EventArgs e)
        {
            // 跳转到登录页面
            NavigationService.Navigate(new Uri("/LogAndReg.xaml", UriKind.Relative));
        }
        
        private void LongListSelector_Tap_1(object sender, System.Windows.Input.GestureEventArgs e)
        {
            // 在此处添加事件处理程序实现。
            // var listSelector = sender as LongListSelector;
            // var selectedItem = listSelector.SelectedItem as TJUDianPing.ViewModels.ItemViewModel;
            //if(selectedItem != null)
            NavigationService.Navigate(new Uri("/LogAndReg.xaml", UriKind.Relative));
        }

        private void StackPanel_Tap_1(object sender, System.Windows.Input.GestureEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
			NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }
    }

}