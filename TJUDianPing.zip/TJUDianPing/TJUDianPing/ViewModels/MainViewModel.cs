﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using TJUDianPing.Resources;

namespace TJUDianPing.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public MainViewModel()
        {
            this.cafeteriaItems = new ObservableCollection<ItemViewModel>();
            this.restaurantItems = new ObservableCollection<ItemViewModel>();
            this.supermarketItems = new ObservableCollection<ItemViewModel>();
            this.exerciseItems = new ObservableCollection<ItemViewModel>();
            this.fruitsItems = new ObservableCollection<ItemViewModel>();
            this.giftsItems = new ObservableCollection<ItemViewModel>();
            this.entertainmentItems = new ObservableCollection<ItemViewModel>();
            this.hairCuttingItems = new ObservableCollection<ItemViewModel>();
            this.jiebiantanItems = new ObservableCollection<ItemViewModel>();
        }

        /// <summary>
        /// A collection for ItemViewModel objects.
        /// </summary>
        public ObservableCollection<ItemViewModel> cafeteriaItems { get; private set; }
        public ObservableCollection<ItemViewModel> restaurantItems { get; private set; }
        public ObservableCollection<ItemViewModel> supermarketItems { get; private set; }
        public ObservableCollection<ItemViewModel> exerciseItems { get; private set; }
        public ObservableCollection<ItemViewModel> fruitsItems { get; private set; }
        public ObservableCollection<ItemViewModel> giftsItems { get; private set; }
        public ObservableCollection<ItemViewModel> entertainmentItems { get; private set; }
        public ObservableCollection<ItemViewModel> hairCuttingItems { get; private set; }
        public ObservableCollection<ItemViewModel> jiebiantanItems { get; private set; }

        private string _sampleProperty = "Sample Runtime Property Value";

        private String[] allType = { "食堂", "餐厅", "超市", "健身", "水果", "礼品店", "娱乐", "美发", "街边摊" };
        /// <summary>
        /// Sample ViewModel property; this property is used in the view to display its value using a Binding
        /// </summary>
        /// <returns></returns>
        public string SampleProperty
        {
            get
            {
                return _sampleProperty;
            }
            set
            {
                if (value != _sampleProperty)
                {
                    _sampleProperty = value;
                    NotifyPropertyChanged("SampleProperty");
                }
            }
        }

        /// <summary>
        /// Sample property that returns a localized string
        /// </summary>
        public string LocalizedSampleProperty
        {
            get
            {
                return AppResources.SampleProperty;
            }
        }

        public bool IsDataLoaded
        {
            get;
            private set;
        }

        /// <summary>
        /// Creates and adds a few ItemViewModel objects into the Items collection.
        /// </summary>
        public void LoadData()
        {
            // Sample data; replace with real data

            for (int i = 0; i < allType.Length; i++)
            {
                StoreAction.SelectTypes(allType[i]);
            }
            this.IsDataLoaded = true;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}