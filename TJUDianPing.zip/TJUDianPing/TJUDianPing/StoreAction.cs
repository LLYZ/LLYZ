﻿using Microsoft.WindowsAzure.MobileServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TJUDianPing.ViewModels;

namespace TJUDianPing
{
    class StoreAction
    {
        private static MobileServiceCollection<Store, Store> storeList;

        private static IMobileServiceTable<Store> storeTable;

        private static List<String> list = new List<string>();

        ///----------------------------------
        /// 以下就是要添加的函数
        /// 
        /// 更新，param：store   根据Score数据表获取，然后更新store表格中的值
        // public void UpdateScore()    

        /// 选择特定分类
        /// param:<classification   string>      return_type:MobileServiceCollection<TodoItem, TodoItem>
        public static async void SelectTypes(String type)
        {
            storeTable = App.MobileService.GetTable<Store>();
            try
            {
                storeList = await storeTable
                    .Where(store => store.Classification == type)
                    .ToCollectionAsync();
            }
            catch (MobileServiceInvalidOperationException e)
            {
                //MessageBox.Show(e.Message, "Error loading items", MessageBoxButton.OK);
            }
            for (int i = 0; i < storeList.Count; i++)
            {
                list.Add(storeList.ElementAt(i).Name);
            }
            for (int i = 0; i < storeList.Count; i++)
            {
                ItemViewModel item = new ItemViewModel { StoreName = storeList.ElementAt(i).Name, Address = storeList.ElementAt(i).Address };
                if (type == "食堂")
                {
                    App.ViewModel.cafeteriaItems.Add(item);
                }
                else if (type == "餐厅")
                {
                    App.ViewModel.restaurantItems.Add(item);
                }
                else if (type == "健身")
                {
                    App.ViewModel.exerciseItems.Add(item);
                }
                else if (type == "水果")
                {
                    App.ViewModel.fruitsItems.Add(item);
                }
                else if (type == "超市")
                {
                    App.ViewModel.supermarketItems.Add(item);
                }
                else if (type == "礼品店")
                {
                    App.ViewModel.giftsItems.Add(item);
                }
                else if (type == "娱乐")
                {
                    App.ViewModel.entertainmentItems.Add(item);
                }
                else if (type == "美发")
                {
                    App.ViewModel.hairCuttingItems.Add(item);
                }
                else if (type == "街边摊")
                {
                    App.ViewModel.jiebiantanItems.Add(item);
                }
                else { }
            }

            storeList.Clear();
        }

        public static List<String> getStoreList()
        {
            return list;
        }
        /// 

        /// 选择特定商店
        /// param：Name（string）
        /// return：store_item(一条记录)
        public static async void SelectedStore(String storeName)
        {
            try
            {
                storeList = await storeTable
                    .Where(store => store.Name == storeName)
                    .ToCollectionAsync();
            }
            catch (MobileServiceInvalidOperationException e)
            {
                //MessageBox.Show(e.Message, "Error loading items", MessageBoxButton.OK);
            }
        }
    }
}
