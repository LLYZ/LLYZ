﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.MobileServices;
using Newtonsoft.Json;

namespace TJUDianPing
{
    public class User
    {
         public int id
        { get; set; }
        // user_id
       
        [JsonProperty(PropertyName = "Account")]
        public string Acount
        { get; set; }


        
        [JsonProperty(PropertyName = "Password")]
        public string Password // password
        { get; set; }


        //public bool is_logged_in = false;
    }
    
}
