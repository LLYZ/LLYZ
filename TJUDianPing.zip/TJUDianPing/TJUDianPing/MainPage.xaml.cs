﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TJUDianPing
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
			
            // Set the data context of the listbox control to the sample data
            DataContext = App.ViewModel;
        }

        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (!App.ViewModel.IsDataLoaded)
            {
                App.ViewModel.LoadData();
            }
        }

        private void ApplicationBarAddButton_Click(object sender, System.EventArgs e)
        {
        	// 跳转到登录页面
			NavigationService.Navigate(new Uri("/LogAndReg.xaml", UriKind.Relative));
        }

        private void LongListSelector_Tap_1(object sender, System.Windows.Input.GestureEventArgs e)
        {
        	// 判断条件，并跳转到相应的商家页面
			NavigationService.Navigate(new Uri("/DetailsPage.xaml", UriKind.Relative));
        }

    }
}