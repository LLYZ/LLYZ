﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.WindowsAzure.MobileServices;
using System.Windows.Media.Imaging;

namespace TJUDianPing
{
    public partial class DetailsPage : PhoneApplicationPage
    {
        public DetailsPage()
        {
            InitializeComponent();
            
        }

        public String name {get; set;}

        public String userName{ get ; set; }

        public string imageSource { get; set; }

        private static IMobileServiceTable<Stores> storeTable;

        private static IMobileServiceTable<Scores> scoresTable;

        private static IMobileServiceTable<Assessment> assessmentTable;

        private static int score = 0;

        private static Stores storeItem = new Stores();

        public bool logged{ get ; set ; }

        protected  async override void OnNavigatedTo(NavigationEventArgs e)
        {
            // 动态获取name！
           
            // 从数据库获取满足条件的store信息
            storeTable = App.MobileService.GetTable<Stores>();
            var result = await storeTable
                    .Where(store => store.Name == name)
                    .ToCollectionAsync();

            storeItem = result.ElementAt(0);
            DateTime DT = DateTime.Now;
            //添加图片               
            mainPic.Source =  new BitmapImage(new Uri(storeItem.Image1,UriKind.RelativeOrAbsolute));
            image1.Source =  new BitmapImage(new Uri(storeItem.Image1,UriKind.RelativeOrAbsolute));
            image2.Source = new BitmapImage(new Uri(storeItem.Image2,UriKind.RelativeOrAbsolute));
            image3.Source = new BitmapImage(new Uri(storeItem.Image3,UriKind.RelativeOrAbsolute));
            // 从数据库获取满足条件的score信息
            scoresTable = App.MobileService.GetTable<Scores>();
            var ScoreResult = await scoresTable
                         .Where(s => s.Name == name)
                         .Where(s => s.Account == userName)
                         .Where(s => DT.Hour + 24 > s.Time.Hour)
                         .ToCollectionAsync();

            assessmentTable = App.MobileService.GetTable<Assessment>();
            var assessmentResult = await assessmentTable
                              .OrderByDescending(a => a.Time)
                              .Where(a => a.Name == name)
                              .ToCollectionAsync()
                              ;
            for (int i = 0; i < assessmentResult.LongCount(); i++)
            {
                var assess = assessmentResult.ElementAt(i);
                addAssess1.Text += assess.Account.ToString() + " 发表于 " + assess.Time.ToString() + "\n";
                addAssess1.Text += assess.Comment + "\n\n";
            }

                // 改变DetailPage.xaml的属性
                storeName.Title = storeItem.Name;
            briefIntro.Text = "\n\t\t" + storeItem.Introduction;
            location.Text = "地理位置：\n\t\t" + storeItem.Address;
            averageSpend.Text = "人均消费：\t" + storeItem.AverageCost.ToString() + "元";
            scores.Text = "评分：\t" + storeItem.Score.ToString();
            tel.Text = "电话号码：\t" + storeItem.PhoneNumber;
            types.Text = "产品分类：\t" + storeItem.Classification;

            // 如果评分过，评分RadioButton不能用
            if (ScoreResult.Count >= 1)
            {
                one.IsEnabled = false;
                two.IsEnabled = false;
                three.IsEnabled = false;
                four.IsEnabled = false;
                five.IsEnabled = false;
            }
            else {
                one.IsEnabled = true;
                two.IsEnabled = true;
                three.IsEnabled = true;
                four.IsEnabled = true;
                five.IsEnabled = true;
            }
                           
            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            var AddAssessPage = e.Content as AddAssessment;
            if (AddAssessPage != null) 
            {
                AddAssessPage.Account = userName;
                AddAssessPage.storeName = name;
                AddAssessPage.logged = logged;
            }
            base.OnNavigatedFrom(e);
            var LogPage = e.Content as LogAndReg;
            if (LogPage != null)
            {
                LogPage.navigatefrom = 1;
                LogPage.storename = name;
            }
        } 
        
        private void login_Click(object sender, System.EventArgs e)
        {
        	// 在此处添加事件处理程序实现。
			NavigationService.Navigate(new Uri("/LogAndReg.xaml", UriKind.Relative));
            
        }

        private async void addAssess_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            //NavigationService.Navigate(new Uri("/AddAssessment.xaml", UriKind.Relative));

            if (logged == false)
            {
                MessageBox.Show("抱歉！请登录！");
            }

            // 从数据库获取满足条件的Assessment信息
            else
            {
                assessmentTable = App.MobileService.GetTable<Assessment>();
                DateTime DT = DateTime.Now;
                var AssessmentResult = await assessmentTable
                         .Where(a => a.Name == name)
                         .Where(a => a.Account == userName)
                         .Where(a => DT.Hour + 24 > a.Time.Hour)
                         .ToCollectionAsync();

                if (AssessmentResult.Count >= 1)
                {
                    MessageBox.Show("对不起！您今天已经对该商家评论过！请明天再来！");
                }
                else {
                    NavigationService.Navigate(new Uri("/AddAssessment.xaml", UriKind.Relative));
                }
            }
        }

        // 获取选取的score值
        private void one_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            score = 1;
        }

        private void two_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
            // 在此处添加事件处理程序实现。
            score = 2;
        }

        private void three_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            score = 3;
        }

        private void four_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            score = 4;
        }

        private void five_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            score = 5;
        }

        private void scoreBoard_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
        }

        // 提交
        private async void confirm_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            if (logged == false)
            {
                MessageBox.Show("抱歉！请登录！");
            }
            else
            {
                if (score == 0)
                {
                    MessageBox.Show("请选择评分");
                }
                else
                {
                    one.IsEnabled = false;
                    two.IsEnabled = false;
                    three.IsEnabled = false;
                    four.IsEnabled = false;
                    five.IsEnabled = false;
                    // 修改Scores表
                    var sc = new Scores { Name = name, Account = userName, Time = DateTime.Now, Score = score };
                    await scoresTable.InsertAsync(sc);
                    // 修改Store表
                    var averageScore = (storeItem.Score * storeItem.ScoreCount + score) / (storeItem.ScoreCount + 1);
                    storeItem.Score = averageScore;
                    storeItem.ScoreCount++;
                    await storeTable.UpdateAsync(storeItem);
                    scores.Text = "评分：\t" + storeItem.Score.ToString();
                    score = 0;
                }
            }
            
        }

    }

}