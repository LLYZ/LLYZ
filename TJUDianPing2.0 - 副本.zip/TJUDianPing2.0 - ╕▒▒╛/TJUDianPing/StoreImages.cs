﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace TJUDianPing
{
    public class StoreImages
    {
        public int id { get; set; }          

        [JsonProperty(PropertyName = "Name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "Image1")]
        public string Image1 { get; set; }

        [JsonProperty(PropertyName = "Image2")]
        public string Image2 { get; set; }

        [JsonProperty(PropertyName = "Image3")]
        public string Image3 { get; set; }

        [JsonProperty(PropertyName = "ImageType")]
        public string ImageType { get; set; }
    }
}
