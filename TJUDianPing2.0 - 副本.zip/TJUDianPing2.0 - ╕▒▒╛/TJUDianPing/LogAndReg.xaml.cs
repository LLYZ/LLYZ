﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.WindowsAzure.MobileServices;
using Newtonsoft.Json;

namespace TJUDianPing
{
    public partial class LogAndReg : PhoneApplicationPage
    {
        User login = new User();
        public MobileServiceCollection<User, User> users;
        public IMobileServiceTable<User> userTable = App.MobileService.GetTable<User>();
        //public static bool is_logged_in = false;
        public LogAndReg()
        {
            InitializeComponent();
        }
        public bool is_logged_in { get; set; }//是否登陆

        public int navigatefrom { get; set; }//从哪个页面跳转过来，从Mainpage跳转过来为0，Detailpage：1，
                                             //AddAssessment:2, ContentPage:3
        public string storename { get; set; }//storename跳转回detailPage的某一商家的名字

        public string userName { get; set; }

        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (!App.ViewModel.IsDataLoaded)
            {
                App.ViewModel.LoadData();
            }                    
        }
        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            var targetPage = e.Content as MainPage;

            if (targetPage != null)
            {
                if (pivot.SelectedIndex != 0)
                {
                    targetPage.userName = userName;
                    targetPage.log = is_logged_in;
                }
                else
                {
                    targetPage.userName = userName;
                    targetPage.log = is_logged_in;
                }
            }
            var detailPage = e.Content as DetailsPage;
            if (detailPage != null)
            {
                detailPage.logged = is_logged_in;
                detailPage.name = storename;                
                if (pivot.SelectedIndex != 0)
                {                   
                    detailPage.userName = userName;
                    detailPage.tips.Text = userName;
                }
                else
                {
                    detailPage.userName = userName;
                    detailPage.tips.Text = userName;
                }
            }

        }
        private void ApplicationBarAddButton_Click(object sender, System.EventArgs e)
        {
            //注册界面
            if (pivot.SelectedIndex != 0)
            {
                var todoItem = new User { Acount = ID1.Text, Password = Password1.Password };
                User_Register(todoItem);
                //timeDelay(9000);
                
            }
            //登录界面
            else
            {
                var todoItem1 = new User { Acount = ID.Text, Password = Password.Password };
                User_LogIn(todoItem1);
                //timeDelay(20000);

            }

        }
        public async void User_Register(User user)
        {
            // This code inserts a new user into the database. When the operation completes
            // and Mobile Services has assigned an Id, the item is added to the CollectionView
            try
            {
                //注册操作
                if (ID1.Text.Length == 0)
                {
                    MessageBox.Show("用户名不许为空");
                }
                else if (Password1.Password != Password_Confirm.Password)
                {
                    MessageBox.Show("密码不匹配");
                }
                else if (Password1.Password == "")
                {
                    MessageBox.Show("密码不允许为空");
                }
                else
                {
                    users = await userTable
                        .Where(User => User.Acount == ID1.Text).ToCollectionAsync();
                    if (users.Count > 0)
                    {
                        is_logged_in = false;
                        MessageBox.Show("已有该用户名");
                    }
                    else
                    {
                        await userTable.InsertAsync(user);
                        is_logged_in = true;
                        userName = ID1.Text;
                        //跳转回主界面
                        if (is_logged_in == true)
                        {
                            switch (navigatefrom)
                            {
                                case 0:
                                    NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
                                    break;
                                case 1:
                                    NavigationService.Navigate(new Uri("/DetailsPage.xaml", UriKind.Relative));
                                    break;
                                //case 2:
                                //    NavigationService.Navigate(new Uri("/AddAssessment.xaml", UriKind.Relative));
                                //    break;
                                //case 3:
                                //    NavigationService.Navigate(new Uri("/ContentPage.xaml", UriKind.Relative));
                                //    break;
                                default:
                                    NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
                                    break;

                            }
                            

                        }
                        else
                        {
                            MessageBox.Show("未登录");
                        }
                    }
                }

            }
            catch (MobileServiceInvalidOperationException e)
            {

                MessageBox.Show(e.Message, "Error ", MessageBoxButton.OK);
            }
        }
        public async void User_LogIn(User user)
        {
            try
            {
                users = await userTable
                    .Where(User => (User.Acount == ID.Text && User.Password == Password.Password))
                    .ToCollectionAsync();
                if (users.LongCount() == 1)
                {
                    is_logged_in = true;
                    userName = ID.Text;
                    //MessageBox.Show(users.LongCount().ToString());
                    //timeDelay(2000);
                }
                if (is_logged_in == true)
                {
                    switch (navigatefrom)
                    {
                        case 0:
                            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
                            break;
                        case 1:
                            NavigationService.Navigate(new Uri("/DetailsPage.xaml", UriKind.Relative));
                            break;
                        //case 2:
                        //    NavigationService.Navigate(new Uri("/AddAssessment.xaml", UriKind.Relative));
                        //    break;
                        //case 3:
                        //    NavigationService.Navigate(new Uri("/ContentPage.xaml", UriKind.Relative));
                        //    break;
                        default:
                            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
                            break;

                    }
                }
                else
                {
                    MessageBox.Show("登录失败，用户名或密码错误");
                }
            }
            catch (MobileServiceInvalidOperationException e)
            {
                MessageBox.Show(e.Message, "Error LogIn", MessageBoxButton.OK);
            }
        }

        private void goThrough_Click(object sender, System.EventArgs e)
        {
        	// 在此处添加事件处理程序实现。
			NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }
        
    }
}