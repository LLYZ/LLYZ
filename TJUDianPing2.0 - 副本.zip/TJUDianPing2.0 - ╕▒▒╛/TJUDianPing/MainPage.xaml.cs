﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TJUDianPing
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
			
            // Set the data context of the listbox control to the sample data
            DataContext = App.ViewModel;
        }
        public string userName { get; set; }

        public String detailname { get; set; }

        public bool log { get; set; }

        //public bool is_logged_in { get; set; }
        // Load data for the ViewModel Items
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (!App.ViewModel.IsDataLoaded)
            {
                App.ViewModel.LoadData();
            }
            if (userName != null)
            {
                tips.Text = userName;
            }
        }
        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            var targetPage = e.Content as LogAndReg;

            if (targetPage != null)
            {
                targetPage.navigatefrom = 0;
                //if (tips.Text == param4)
                //{
                //    var result = MessageBox.Show("您已登陆，是否要注销", "提示", MessageBoxButton.OKCancel);
                //    if (result == MessageBoxResult.OK)
                //    {
                //        tips.Text = "";
                //        targetPage.is_logged_in = false;
                //        targetPage.navigatefrom = -1;
                //        targetPage.userName = "";
                //        NavigationService.Navigate(new Uri("/LogAndReg.xaml", UriKind.Relative));
                //    }
                //    else
                //    {
                //        tips.Text = targetPage.userName;
                //        targetPage.is_logged_in = true;
                //        NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
                //    }
                //}
            }
            var detailPage = e.Content as DetailsPage;
            if (detailPage != null)
            {
                detailPage.logged = log;
                detailPage.userName = userName;
                detailPage.name = detailname;
                detailPage.tips.Text = userName;
            }         
        }
        
        private void ApplicationBarAddButton_Click(object sender, System.EventArgs e)
        {
        	// 跳转到登录页面
			NavigationService.Navigate(new Uri("/LogAndReg.xaml", UriKind.Relative));
        }

        private void LongListSelector_Tap_1(object sender, System.Windows.Input.GestureEventArgs e)
        {
        	// 判断条件，并跳转到相应的商家页面
            var listSelector = sender as LongListSelector;
            var selectedItem = listSelector.SelectedItem as TJUDianPing.ViewModels.ItemViewModel;
            if (selectedItem != null)
            {
                detailname = selectedItem.StoreName;
                NavigationService.Navigate(new Uri("/DetailsPage.xaml?", UriKind.Relative));
            }

        }

    }
}