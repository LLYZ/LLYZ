﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TJUDianPing
{
    class Stores
    {
        public int id { get; set; }           // user_id

        [JsonProperty(PropertyName = "Name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "AverageCost")]
        public int AverageCost { get; set; }

        [JsonProperty(PropertyName = "Score")]
        public float Score { get; set; }

        [JsonProperty(PropertyName = "Address")]
        public string Address { get; set; }

        [JsonProperty(PropertyName = "ScoreCount")]
        public int ScoreCount { get; set; }

        [JsonProperty(PropertyName = "Introduction")]
        public string Introduction { get; set; }

        [JsonProperty(PropertyName = "PhoneNumber")]
        public string PhoneNumber{ get; set; }

        [JsonProperty(PropertyName = "Classification")]
        public string Classification { get; set; }

        [JsonProperty(PropertyName = "Image1")]
        public string Image1 { get; set; }

        [JsonProperty(PropertyName = "Image2")]
        public string Image2 { get; set; }

        [JsonProperty(PropertyName = "Image3")]
        public string Image3 { get; set; }
    }
}
