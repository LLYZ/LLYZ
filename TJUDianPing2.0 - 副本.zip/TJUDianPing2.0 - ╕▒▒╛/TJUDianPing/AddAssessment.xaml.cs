﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.WindowsAzure.MobileServices;

namespace TJUDianPing
{
    public partial class AddAssessment : PhoneApplicationPage
    {
        public AddAssessment()
        {
            InitializeComponent();
            
        }
        public bool logged { get; set; }
        
        public String storeName { get; set; }

        public String Account { get; set; }

        private async void ApplicationBarAddButton_Click(object sender, System.EventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            if (comment2.Text == "") 
            {
                MessageBox.Show("评论不能为空！");
            }

            else if (comment2.Text.Length > 30)
            {
                MessageBox.Show("评论字数请限制在30字以内！");
            }

            else
            {
                IMobileServiceTable<Assessment> assessmentTable = App.MobileService.GetTable<Assessment>();
                var assess = new Assessment { Name = storeName, Account = Account, Time = DateTime.Now, Comment = comment2.Text };
                await assessmentTable.InsertAsync(assess);
                NavigationService.Navigate(new Uri("/DetailsPage.xaml", UriKind.Relative));
            }
        }
        
        private void tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
        	// 在此处添加事件处理程序实现。
            
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            var detailsPage = e.Content as DetailsPage;
            if (detailsPage != null)
            {
                detailsPage.userName = Account;
                detailsPage.logged = logged;
                detailsPage.name = storeName;
            }
            base.OnNavigatedFrom(e);
            //var logPage = e.Content as LogAndReg;
            //if (logPage != null)
            //{
            //    logPage.navigatefrom = 2;
            //}
        } 
    }
}