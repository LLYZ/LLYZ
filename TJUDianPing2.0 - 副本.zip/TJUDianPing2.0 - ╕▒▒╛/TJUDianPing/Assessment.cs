﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TJUDianPing
{
    class Assessment
    {
        public int id
        { get; set; }
        // user_id

        [JsonProperty(PropertyName = "Name")]
        public string Name
        { get; set; }

        [JsonProperty(PropertyName = "Account")]
        public string Account
        { get; set; }

        [JsonProperty(PropertyName = "Time")]
        public DateTime Time
        { get; set; }

        [JsonProperty(PropertyName = "Comment")]
        public string Comment 
        { get; set; }
    }
}
